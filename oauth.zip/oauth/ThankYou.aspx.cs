﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;


using Google.Api.Ads.AdWords.Lib;
using Google.Api.Ads.AdWords.Util.Reports;
using Google.Api.Ads.AdWords.v201609;
using Google.Api.Ads.Common.Lib;
using Google.Api.Ads.Common.Util.Reports;
using System.Text.RegularExpressions;
using System.IO;
using System.Net.Mail;
using System.Net;
using System.Text;
using Newtonsoft.Json.Linq;

namespace meet_emma_oauth
{
    public partial class ThankYou : System.Web.UI.Page
    {
        public string email = "";
        public string company = "";
        public string person = "";
        public string userid = "";
        public string payload = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            Database db = DatabaseFactory.CreateDatabase();
            DbCommand dbc = db.GetStoredProcCommand("USP_GetClientData");
            db.AddInParameter(dbc, "@cid", DbType.String, Request.QueryString["cid"]);
            DataSet ds = db.ExecuteDataSet(dbc);

            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            userid = new string(Enumerable.Repeat(chars, 20)
              .Select(s => s[random.Next(s.Length)]).ToArray());

            if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                email = Convert.ToString(ds.Tables[0].Rows[0]["ToClient"]);
                company = Convert.ToString(ds.Tables[0].Rows[0]["Company_Name"]);
                person = Convert.ToString(ds.Tables[0].Rows[0]["Client_Name"]);
            }
            //payload = "\"email\":\""+email+"\"";


            //string date1 = DateTime.Now.AddDays(-30).ToString("dd MMM yyy") + " - " + DateTime.Now.AddDays(-1).ToString("dd MMM yyy");
            //string date2 = DateTime.Now.AddDays(-60).ToString("dd MMM yyy") + " - " + DateTime.Now.AddDays(-31).ToString("dd MMM yyy");

            //payload = payload + ",\"date\":\""+date1+"\"";
            //payload = payload + ",\"compare_date\":\"" + date2 + "\"";

            //string cid = Convert.ToString(Request.QueryString["cid"]);


            //DataSet ds1 = new DataSet();

            //string filePath = "d:\\adwords\\litereport_"+cid+".xml";// Path.GetTempFileName();
            //File.Delete(filePath);

            //AdWordsUser user = new AdWordsUser();
            //OAuth2ProviderForApplications oAuth;

            //AdWordsAppConfig config = (user.Config as AdWordsAppConfig);


            ////if (config.OAuth2Mode == OAuth2Flow.APPLICATION && string.IsNullOrEmpty(config.OAuth2RefreshToken))
            //{

            //    oAuth = new OAuth2ProviderForApplications(config);

            //    oAuth.RefreshToken = "1/OOC7dOHc8GVL5akg_NsLiYyNQRYL6v_Yrzj54KaYrIwMEudVrK5jSpoR30zcRFq6";
            //    oAuth.ClientId = "645807510586-ta73tevafb79v8cfu32kemeftd2ermp7.apps.googleusercontent.com";
            //    oAuth.ClientSecret = "jNiWP30MtIHngJBOz-CEmt8T";

            //    user.OAuthProvider = (OAuth2ProviderForApplications)oAuth;
            //}

            //#region account data

            //ReportDefinition definition = new ReportDefinition();
            //(user.Config as AdWordsAppConfig).ClientCustomerId = cid;
            //// Create selector.
            //Selector selector = new Selector();
            //selector.fields = new string[] { "AccountDescriptiveName", "Interactions", "Impressions", "Cost", "Ctr", "AverageCpc", "AverageCpm", "Conversions", "ConversionRate", "CostPerConversion", "SearchBudgetLostImpressionShare", "SearchRankLostImpressionShare" };
            //definition.selector = selector;
            //definition.reportName = "Todays CRITERIA_PERFORMANCE_REPORT";
            //definition.reportType = ReportDefinitionReportType.ACCOUNT_PERFORMANCE_REPORT;
            //definition.downloadFormat = DownloadFormat.XML;
            //definition.dateRangeType = ReportDefinitionDateRangeType.LAST_30_DAYS;
            //try
            //{
            //    ReportUtilities utilities = new ReportUtilities(user, "v201603", definition);
            //    //utilities.GetResponse().Save(filePath);
            //    System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
            //    utilities.GetResponse().Save(filePath);
            //    ds1.ReadXml(filePath);
            //    DataRow row = ds1.Tables["row"].Rows[0];

            //    string clicks = Regex.Replace(Convert.ToString(row["interactions"]), @"[A-Za-z\s]", string.Empty);

            //    payload = payload + ",\"clicks\":\""+clicks.Replace("--", "0").Replace(",", "").Trim()+"\",\"cost\":\""+ decimal.Round(Convert.ToDecimal(row["cost"]) / 1000000,2)+"\",\"convRate\":\""+Convert.ToString(row["convRate"]).Replace("%", "").Trim()+"\"";
            //    payload = payload + ",\"costConv\":\"" + decimal.Round(Convert.ToDecimal(row["costConv"]) / 1000000,2) + "\",\"searchLostISBudget\":\"" + Convert.ToString(row["searchLostISBudget"]).Replace("--", "0").Replace("%", "").Replace(">", string.Empty).Replace("<", string.Empty).Trim() + "\"";
            //    payload = payload + ",\"searchLostISRank\":\"" + Convert.ToString(row["searchLostISRank"]).Replace("--", "0").Replace("%", "").Replace(">", string.Empty).Replace("<", string.Empty).Trim() + "\"";
            //    payload = payload + ",\"ctr\":\"" + Convert.ToString(row["ctr"]) + "\"";
            //    payload = payload + ",\"cpc\":\"" + decimal.Round(Convert.ToDecimal(row["avgCPC"])/1000000,2) + "\"";
            //    payload = payload + ",\"conv\":\"" + decimal.Round(Convert.ToDecimal(row["conversions"]),0) + "\"";
            //    payload = payload + ",\"imps\":\""+decimal.Round(Convert.ToDecimal(row["impressions"]),0)+"\"";
            //    //payload = "{" + payload + "}";



            //}
            //catch (Exception ex)
            //{

            //}

            //#endregion

            //#region keyword Data
            //File.Delete(filePath);
            //ReportDefinition dfn1 = new ReportDefinition();
            //(user.Config as AdWordsAppConfig).ClientCustomerId = cid;
            //// Create selector.
            //Selector selector1 = new Selector();
            //selector1.fields = new string[] { "CustomerDescriptiveName", "Criteria", "KeywordMatchType", "Clicks", "Impressions", "Cost", "Ctr", "AverageCpc", "AverageCpm", "ConvertedClicks", "Conversions", "CostPerConvertedClick", "QualityScore", "Status", "AdNetworkType1" };
            //dfn1.selector = selector1;
            //dfn1.reportName = "Todays CRITERIA_PERFORMANCE_REPORT";
            //dfn1.reportType = ReportDefinitionReportType.KEYWORDS_PERFORMANCE_REPORT;
            //dfn1.downloadFormat = DownloadFormat.XML;
            //dfn1.dateRangeType = ReportDefinitionDateRangeType.LAST_30_DAYS;
            //try
            //{
            //    ReportUtilities utilities = new ReportUtilities(user, "v201603", dfn1);
            //    //utilities.GetResponse().Save(filePath);
            //    System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
            //    utilities.GetResponse().Save(filePath);
            //    DataSet keyword = new DataSet();
            //    keyword.ReadXml(filePath);
            //    DataTable dt = keyword.Tables["row"];

            //    DataView dv = new DataView();
            //    dv.Table = dt;
            //    dv.RowFilter = "matchType = 'Broad'";
            //    DataTable dt1 = dv.ToTable();
            //    int broad = dt1.Rows.Count;

            //    dv = new DataView();
            //    dv.Table = dt;
            //    dv.RowFilter = "matchType = 'Exact'";
            //    dt1 = dv.ToTable();
            //    int exact = dt1.Rows.Count;

            //    dv = new DataView();
            //    dv.Table = dt;
            //    dv.RowFilter = "matchType = 'Phrase'";
            //    dt1 = dv.ToTable();
            //    int phrase = dt1.Rows.Count;

            //    int total = exact + broad + phrase;

            //    decimal percbroad = decimal.Round(Convert.ToDecimal((broad / total) * 100), 2);
            //    decimal percphrase = decimal.Round(Convert.ToDecimal((phrase / total) * 100), 2);
            //    decimal percexact = decimal.Round(Convert.ToDecimal((exact / total) * 100), 2);

            //    string str = "Out of a total of= " + total + " active keywords in your account: <br/>";
            //    str += "Broad-  " + broad + " or " + percbroad + "% <br/> Phrase- " + phrase + " or " + percphrase + "% <br/>Exact-" + exact + " or " + percexact + "% <br/>";

            //    payload = payload + ",\"matchtypeanalysis\":\""+str+"\"";

            //    var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://charturl.com/short-urls.json?api_key=pak-c40bee6f-a443-4888-b033-9c67a58684db");
            //    httpWebRequest.ContentType = "application/json";
            //    httpWebRequest.Method = "POST";
            //    using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            //    {
            //        string json = "{\"template\":\"newpiechart\",\"options\" :{\"data\":{\"columns\": [[\"Exact\", " + exact + "],[\"Phrase\"," + phrase + "],[\"Broad\"," + broad + "]]}}}";
            //        streamWriter.Write(json); streamWriter.Flush(); streamWriter.Close();
            //    }
            //    var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            //    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            //    {
            //        var result = streamReader.ReadToEnd(); JObject res1 = JObject.Parse(result);
            //        payload = payload + ",\"matchtypechart\":" + Convert.ToString(res1["short_url"]) ; 
            //    }

            //    DataTable ReportTable = new DataTable();
            //    ReportTable.Columns.Add("keyword");
            //    ReportTable.Columns.Add("matchtype");
            //    ReportTable.Columns.Add("clicks");
            //    ReportTable.Columns.Add("impressions");
            //    ReportTable.Columns.Add("cost");
            //    ReportTable.Columns.Add("qualityScore");
            //    ReportTable.Columns.Add("cid");

            //    DataRow newrow;
            //    foreach (DataRow row in dt.Rows)
            //    {
            //        newrow = ReportTable.NewRow();
            //        newrow[0] = row["keyword"];
            //        newrow[1] = row["matchType"];
            //        newrow[2] = row["clicks"];
            //        newrow[3] = row["impressions"];
            //        newrow[4] = (Convert.ToDecimal(row["cost"]) / 1000000);
            //        newrow[5] = row["qualityScore"];
            //        newrow[6] = Convert.ToString("9930359558");
            //        ReportTable.Rows.Add(newrow);

            //    }

            //    DataSet TotalReport = new DataSet();
            //    TotalReport.Tables.Add(ReportTable);
            //    TotalReport.WriteXml(filePath);

            //    DbCommand dbc1 = db.GetStoredProcCommand("USP_BroadplaceLite_Report");
            //    db.AddInParameter(dbc1, "XMLPATH", DbType.String, filePath);
            //    db.AddInParameter(dbc1, "type", DbType.String, "keyword");
            //    dbc1.CommandTimeout = 50000;
            //    dbc1.CommandType = CommandType.StoredProcedure;
            //    DataSet newds = db.ExecuteDataSet(dbc1);

            //    if (newds != null && newds.Tables[0].Rows.Count > 0)
            //    {
            //        for (int i = 0; i < newds.Tables[0].Rows.Count; i++)
            //        {                        
            //            payload = payload + ",\"keyword"+(i+1)+"\":\"" + newds.Tables[0].Rows[i]["keyword"] + "\", \"keywordmatch"+(i+1)+"\":\"" + newds.Tables[0].Rows[i]["matchType"] + "\",\"keywordimps"+(i+1)+"\":\"" + decimal.Round(Convert.ToDecimal(newds.Tables[0].Rows[i]["imps"]), 0) + "\"";
            //            payload = payload + ",\"keywordclick"+(i+1)+"\":\"" + decimal.Round(Convert.ToDecimal(newds.Tables[0].Rows[i]["clicks"]), 0) + "\", \"keywordctr"+(i+1)+"\":\"" + decimal.Round(Convert.ToDecimal(newds.Tables[0].Rows[i]["ctr"]), 2) + "\"";
            //            payload = payload + ",\"keywordcost"+(i+1)+"\":\"" + decimal.Round(Convert.ToDecimal(newds.Tables[0].Rows[i]["cost"]), 2) + "\", \"keywordconv"+(i+1)+"\":\"" + newds.Tables[0].Rows[i]["conv"] + "\" ";
            //        }
            //    }


            //    if (newds != null && newds.Tables[1] != null && newds.Tables[1].Rows.Count > 0)
            //    {
            //        int high = 0, middle = 0, low = 0;
            //        foreach (DataRow dr in newds.Tables[1].Rows)
            //        {
            //            if (Convert.ToInt32(dr["qualityscore"]) >= 7) { high += Convert.ToInt32(dr["keycount"]); }
            //            else if (Convert.ToInt32(dr["qualityscore"]) >= 4 && Convert.ToInt32(dr["qualityscore"]) <= 6) { middle += Convert.ToInt32(dr["keycount"]); }
            //            else { low += Convert.ToInt32(dr["keycount"]); }
            //        }

            //        total = high + middle + low;
            //        string qualityScoreOutcome = "Out of a total of= " + total + " active keywords in your account <br/>";
            //        qualityScoreOutcome += "Quality Score Above 7 are " + high + " <br/>Quality Score Between 5-7 are " + middle + " <br/>Quality Score Below 4- " + low + "<br/>";

            //        payload = payload + ",\"qscoreanalysis\":\""+qualityScoreOutcome+"\"";

            //        httpWebRequest = (HttpWebRequest)WebRequest.Create("https://charturl.com/short-urls.json?api_key=pak-c40bee6f-a443-4888-b033-9c67a58684db");
            //        httpWebRequest.ContentType = "application/json";
            //        httpWebRequest.Method = "POST";
            //        using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            //        {
            //            string json = "{\"template\":\"newpiechart\",\"options\" :{\"data\":{\"columns\": [[\"Above 7\", " + high + "],[\"Between 5 & 7\"," + middle + "],[\"Below 4\"," + low + "]]}}}";
            //            streamWriter.Write(json); streamWriter.Flush(); streamWriter.Close();
            //        }
            //        httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            //        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            //        {
            //            var result = streamReader.ReadToEnd(); JObject res1 = JObject.Parse(result);
            //            payload = payload + ",\"qscorechart\":" + Convert.ToString(res1["short_url"]);
            //        }
            //    }

            //    if (newds != null && newds.Tables[2] != null && newds.Tables[2].Rows.Count > 0)
            //    {
            //        payload = payload + ",\"qualityscore\":" + Convert.ToString(newds.Tables[2].Rows[0]["qscore"]);
            //    }
            //    else
            //    {
            //        payload = payload + ",\"qualityscore\": \"0\"";
            //    }

            //}
            //catch (Exception ex)
            //{

            //}
            //#endregion

            //#region adgroup

            //File.Delete(filePath);

            //ReportDefinition dfn2 = new ReportDefinition();
            //(user.Config as AdWordsAppConfig).ClientCustomerId = cid;
            //// Create selector.
            //Selector selector2 = new Selector();
            //selector2.fields = new string[] { "CustomerDescriptiveName", "AdGroupName", "Clicks", "Impressions", "Cost", "Ctr", "AverageCpc", "AverageCpm", "ConvertedClicks", "Conversions", "CostPerConvertedClick" };
            //dfn2.selector = selector2;
            //dfn2.reportName = "Todays CRITERIA_PERFORMANCE_REPORT";
            //dfn2.reportType = ReportDefinitionReportType.ADGROUP_PERFORMANCE_REPORT;
            //dfn2.downloadFormat = DownloadFormat.XML;
            //dfn2.dateRangeType = ReportDefinitionDateRangeType.LAST_30_DAYS;
            //try
            //{
            //    ReportUtilities utilities = new ReportUtilities(user, "v201603", dfn2);
            //    //utilities.GetResponse().Save(filePath);
            //    System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
            //    utilities.GetResponse().Save(filePath);
            //    DataSet adgroup = new DataSet();
            //    adgroup.ReadXml(filePath);

            //    DataTable ReportTable = new DataTable();
            //    ReportTable.Columns.Add("AdGroupName");
            //    ReportTable.Columns.Add("clicks");
            //    ReportTable.Columns.Add("impressions");
            //    ReportTable.Columns.Add("cost");
            //    ReportTable.Columns.Add("conv");

            //     DataRow newrow;
            //     foreach (DataRow row1 in adgroup.Tables["row"].Rows)
            //     {
            //         newrow = ReportTable.NewRow();
            //         newrow[0] = row1["adGroup"];
            //         newrow[1] = row1["clicks"];
            //         newrow[2] = row1["impressions"];
            //         newrow[3] = (Convert.ToDecimal(row1["cost"]) / 1000000);
            //         newrow[4] = row1["conversions"];

            //         ReportTable.Rows.Add(newrow);
            //     }

            //     DataSet TotalReport = new DataSet();
            //     TotalReport.Tables.Add(ReportTable);
            //     TotalReport.WriteXml(filePath);

            //     DbCommand dbc1 = db.GetStoredProcCommand("USP_BroadplaceLite_Report");
            //     db.AddInParameter(dbc1, "XMLPATH", DbType.String, filePath);
            //     db.AddInParameter(dbc1, "type", DbType.String, "adgroup");
            //     dbc1.CommandTimeout = 50000;
            //     dbc1.CommandType = CommandType.StoredProcedure;
            //     DataSet ds2 = db.ExecuteDataSet(dbc1);

            //     if (ds2 != null && ds2.Tables[0].Rows.Count > 0)
            //     {
            //         for (int i = 0; i < ds2.Tables[0].Rows.Count; i++)
            //         {
            //             payload = payload + ",\"adgroup" + (i + 1) + "\":\"" + ds2.Tables[0].Rows[i]["adgroupname"] + "\", \"adgroup-click"+ (i + 1) +"\":\"" + decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[i]["clicks"]),0) + "\"";

            //         }
            //     }

            //}
            //catch (Exception ex)
            //{

            //}

            //#endregion


            //#region actdata


            //DataTable ReportTable1 = new DataTable();

            //ReportTable1.Columns.Add("account");
            //ReportTable1.Columns.Add("date");
            //ReportTable1.Columns.Add("clicks");
            //ReportTable1.Columns.Add("impressions");
            //ReportTable1.Columns.Add("cost");
            //ReportTable1.Columns.Add("ctr");
            //ReportTable1.Columns.Add("avgCPC");
            //ReportTable1.Columns.Add("avgCPM");
            //ReportTable1.Columns.Add("conversions");

            //File.Delete(filePath);

            //ReportDefinition dfn3 = new ReportDefinition();
            //(user.Config as AdWordsAppConfig).ClientCustomerId = cid;
            //// Create selector.
            //Selector selector3 = new Selector();
            //selector3.fields = new string[] { "AccountDescriptiveName", "Date", "Interactions", "Impressions", "Cost", "Ctr", "AverageCpc", "AverageCpm", "Conversions", "SearchBudgetLostImpressionShare", "SearchRankLostImpressionShare" };
            //dfn3.selector = selector3;
            //dfn3.reportName = "Todays CRITERIA_PERFORMANCE_REPORT";
            //dfn3.reportType = ReportDefinitionReportType.ACCOUNT_PERFORMANCE_REPORT;
            //dfn3.downloadFormat = DownloadFormat.XML;
            //dfn3.dateRangeType = ReportDefinitionDateRangeType.ALL_TIME;
            //try
            //{
            //    ReportUtilities utilities = new ReportUtilities(user, "v201603", dfn3);
            //    //utilities.GetResponse().Save(filePath);
            //    System.Xml.XmlDocument xml = new System.Xml.XmlDocument();
            //    utilities.GetResponse().Save(filePath);
            //    DataSet ds3 = new DataSet();
            //    ds3.ReadXml(filePath);

            //    DataRow newrow;
            //    foreach (DataRow row in ds3.Tables["row"].Rows)
            //    {
            //        newrow = ReportTable1.NewRow();
            //        newrow[0] = row["account"];
            //        newrow[1] = row["day"];
            //        string clicks = Regex.Replace(Convert.ToString(row["interactions"]), @"[A-Za-z\s]", string.Empty);
            //        newrow[2] = clicks.Replace("--", "0").Replace(",", "").Trim();
            //        newrow[3] = row["impressions"];
            //        newrow[4] = (Convert.ToDecimal(row["cost"]) / 1000000);
            //        newrow[5] = Convert.ToString(row["ctr"]).Replace("%", "").Trim();
            //        newrow[6] = row["avgCPC"];
            //        newrow[7] = row["avgCPM"];
            //        newrow[8] = row["conversions"];

            //        ReportTable1.Rows.Add(newrow);
            //    }

            //    DataSet TotalReport = new DataSet();
            //    TotalReport.Tables.Add(ReportTable1);
            //    TotalReport.WriteXml(filePath);

            //    DbCommand dbc2 = db.GetStoredProcCommand("USP_BroadplaceLite_Report");
            //    db.AddInParameter(dbc2, "XMLPATH", DbType.String, filePath);
            //    db.AddInParameter(dbc2, "type", DbType.String, "actdata");
            //    dbc2.CommandTimeout = 50000;
            //    dbc2.CommandType = CommandType.StoredProcedure;
            //    DataSet ds2 = db.ExecuteDataSet(dbc2);

            //    if (ds2 != null && ds2.Tables[0].Rows.Count > 0)
            //    {
            //        payload = payload + ",\"prev_clicks\":\""+decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["clicks"]),0)+"\"";
            //        payload = payload + ",\"prev_imps\":\""+decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["imps"]),0)+"\"";
            //        payload = payload + ",\"prev_conv\":\""+decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["conv"]),0)+"\"";
            //        payload = payload + ",\"prev_ctr\":\""+ decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["ctr"]),2)+"\"";
            //        payload = payload + ",\"prev_cost\":\""+ decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["cost"]),2)+"\"";
            //        payload = payload + ",\"prev_cpc\":\"" + decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["cpc"]),2) + "\"";
            //    }

            //    decimal cpc1 = 0.00m; decimal cpc2 = 0.00m; decimal cost1 = 0.00m; decimal cost2 = 0.00m; decimal conv1 = 0.00m; decimal conv2 = 0.00m;
            //    decimal ctr1 = 0.00m; decimal ctr2 = 0.00m; decimal imp1 = 0.00m; decimal imp2 = 0.00m; decimal click1 = 0.00m; decimal click2 = 0.00m;

            //    if (ds2.Tables[0] != null && ds2.Tables[0].Rows.Count > 0)
            //    {
            //        cost2 = Convert.ToDecimal(ds2.Tables[0].Rows[0]["cost"]);
            //        conv2 = Convert.ToDecimal(ds2.Tables[0].Rows[0]["conv"]);
            //        ctr2 = decimal.Round(Convert.ToDecimal(ds2.Tables[0].Rows[0]["ctr"]), 2);
            //        imp2 = Convert.ToDecimal(ds2.Tables[0].Rows[0]["imps"]);
            //        click2 = Convert.ToDecimal(ds2.Tables[0].Rows[0]["clicks"]);

            //        if (Convert.ToInt32(ds2.Tables[0].Rows[0]["clicks"]) != 0)
            //        { cpc2 = decimal.Round((Convert.ToDecimal(ds2.Tables[0].Rows[0]["cost"]) / Convert.ToDecimal(ds2.Tables[0].Rows[0]["clicks"])), 2); }
            //    }

            //    if (ds1.Tables["row"] != null && ds1.Tables["row"].Rows.Count > 0)
            //    {
            //        cost1 = decimal.Round(Convert.ToDecimal(ds1.Tables["row"].Rows[0]["cost"]) / 1000000,2);
            //        conv1 = decimal.Round(Convert.ToDecimal(ds1.Tables["row"].Rows[0]["conversions"]),0);
            //        ctr1 = decimal.Round(Convert.ToDecimal(Convert.ToString(ds1.Tables["row"].Rows[0]["ctr"]).Replace("%", "").Trim()), 2);
            //        imp1 = decimal.Round(Convert.ToDecimal(ds1.Tables["row"].Rows[0]["impressions"]),0);

            //        string clicks = Regex.Replace(Convert.ToString(ds1.Tables["row"].Rows[0]["interactions"]), @"[A-Za-z\s]", string.Empty);
            //        click1 = Convert.ToDecimal(clicks.Replace("--", "0").Replace(",", "").Trim());

            //        if (ds1.Tables["row"] != null && Convert.ToInt32(click1) != 0)
            //        { cpc1 = decimal.Round((cost1 / click1), 2); }
            //    }

            //    if (Convert.ToInt32(click2) != 0)
            //    {
            //        payload = payload + ",\"clickperc\":\""+ decimal.Round((((click1 - click2) / click2) * 100), 2).ToString() + "\"";
            //    }
            //    else { payload = payload + ",\"clickperc\":\"0\"";}

            //    if (Convert.ToInt32(imp2) != 0)
            //    {
            //        payload = payload + ",\"imprperc\":\""+ decimal.Round((((imp1 - imp2) / imp2) * 100), 2).ToString() + "\"";
            //    }
            //    else { payload = payload + ",\"imprperc\":\"0\"";}

            //    if (Convert.ToDecimal(ctr2) != 0)
            //    {
            //        payload = payload + ",\"ctrperc\":\""+ decimal.Round((((ctr1 - ctr2) / ctr2) * 100), 2).ToString()+"\"";
            //    }
            //    else { payload = payload + ",\"ctrperc\":\"0\"";}

            //    if (Convert.ToInt32(conv2) != 0)
            //    {
            //        payload = payload + ",\"convperc\":\""+ decimal.Round((((conv1 - conv2) / conv2) * 100), 2).ToString() + "\"";
            //    }
            //    else
            //    {
            //        payload = payload + ",\"convperc\":\""+ (Convert.ToInt32(conv2) * 100).ToString() + "\"";
            //    }

            //    if (Convert.ToInt32(cost2) != 0)
            //    {
            //        payload = payload + ",\"costperc\":\""+ decimal.Round((((cost1 - cost2) / cost2) * 100), 2).ToString() + "\"";
            //    }
            //    else { payload = payload + ",\"costperc\":\"0\"";}

            //    if (Convert.ToDecimal(cpc2) != 0)
            //    {
            //        payload = payload + ",\"cpcperc\":\"" + decimal.Round((((cpc1 - cpc2) / cpc2) * 100), 2).ToString() + "\"";
            //    }
            //    else { payload = payload + ",\"cpcperc\":\"0\""; }



            //    var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://charturl.com/short-urls.json?api_key=pak-68fee704-19ff-4220-9187-5f77503bcb7e");
            //    httpWebRequest.ContentType = "application/json";
            //    httpWebRequest.Method = "POST";
            //    using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            //    {
            //        string json = "{\"template\":\"weekly-activity\",\"options\" :{\"data\":{\"columns\": [[\"Clicks\", " + ds2.Tables[1].Rows[0]["clicks"] + "]]}}}";
            //        streamWriter.Write(json); streamWriter.Flush(); streamWriter.Close();
            //    }
            //    var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            //    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            //    {
            //        var result = streamReader.ReadToEnd(); JObject res = JObject.Parse(result);
            //        payload = payload + ",\"clickchart\":" + Convert.ToString(res["short_url"]);
            //    }

            //    var httpWebRequest1 = (HttpWebRequest)WebRequest.Create("https://charturl.com/short-urls.json?api_key=pak-68fee704-19ff-4220-9187-5f77503bcb7e");
            //    httpWebRequest1.ContentType = "application/json";
            //    httpWebRequest1.Method = "POST";
            //    using (var streamWriter = new StreamWriter(httpWebRequest1.GetRequestStream()))
            //    {
            //        string json = "{\"template\":\"weekly-activity\",\"options\" :{\"data\":{\"columns\": [[\"Conv\", " + ds2.Tables[1].Rows[0]["conv"] + "]]}}}";
            //        streamWriter.Write(json); streamWriter.Flush(); streamWriter.Close();
            //    }
            //    var httpResponse1 = (HttpWebResponse)httpWebRequest1.GetResponse();
            //    using (var streamReader = new StreamReader(httpResponse1.GetResponseStream()))
            //    {
            //        var result = streamReader.ReadToEnd(); JObject res = JObject.Parse(result);
            //        payload = payload + ",\"convchart\":" + Convert.ToString(res["short_url"]);
            //    }

            //    var httpWebRequest2 = (HttpWebRequest)WebRequest.Create("https://charturl.com/short-urls.json?api_key=pak-68fee704-19ff-4220-9187-5f77503bcb7e");
            //    httpWebRequest2.ContentType = "application/json";
            //    httpWebRequest2.Method = "POST";
            //    using (var streamWriter = new StreamWriter(httpWebRequest2.GetRequestStream()))
            //    {
            //        string json = "{\"template\":\"weekly-activity\",\"options\" :{\"data\":{\"columns\": [[\"CPC\", " + ds2.Tables[1].Rows[0]["cpc"] + "]]}}}";
            //        streamWriter.Write(json); streamWriter.Flush(); streamWriter.Close();
            //    }
            //    var httpResponse2 = (HttpWebResponse)httpWebRequest2.GetResponse();
            //    using (var streamReader = new StreamReader(httpResponse2.GetResponseStream()))
            //    {
            //        var result = streamReader.ReadToEnd(); JObject res = JObject.Parse(result);
            //        payload = payload + ",\"cpcchart\":" + Convert.ToString(res["short_url"]);
            //    }

            //}
            //catch (Exception ex)
            //{
            //}


            //#endregion


            //#region extensions

            //definition = new ReportDefinition();

            //DataTable tbl = new DataTable();
            //tbl.Columns.Add("account");
            //tbl.Columns.Add("extensiontype");
            //tbl.Columns.Add("cost");
            //tbl.Columns.Add("clicks");
            //tbl.Columns.Add("impressions");

            //File.Delete(filePath);
            //(user.Config as AdWordsAppConfig).ClientCustomerId = cid;
            //ReportDefinition dfn = new ReportDefinition();
            //// Create selector.
            //Selector sl = new Selector();
            //sl.fields = new string[] { "AccountDescriptiveName", "ExtensionPlaceholderType", "Clicks", "Cost", "Impressions" };
            //dfn.selector = sl;
            //dfn.reportName = "Todays CRITERIA_PERFORMANCE_REPORT";
            //dfn.reportType = ReportDefinitionReportType.PLACEHOLDER_REPORT;
            //dfn.downloadFormat = DownloadFormat.XML;
            //dfn.dateRangeType = ReportDefinitionDateRangeType.LAST_30_DAYS;

            //try
            //{
            //    ReportUtilities utilities = new ReportUtilities(user, "v201603", dfn);
            //    utilities.GetResponse().Save(filePath);

            //    DataSet ext = new DataSet();
            //    ext.ReadXml(filePath);

            //    DataRow newrow;
            //    foreach (DataRow row in ext.Tables["row"].Rows)
            //    {
            //        newrow = tbl.NewRow();
            //        string extype = "";

            //        switch (Convert.ToString(row["feedPlaceholderType"]))
            //        {
            //            case "1": extype = "sitelinks extensions"; break;
            //            case "2": extype = "call extensions"; break;
            //            case "3": extype = "app extensions"; break;
            //            case "7": extype = "location extensions"; break;
            //            case "8": extype = "review extensions"; break;
            //            case "17": extype = "callouts extensions"; break;
            //            case "24": extype = "structured snippets extensions"; break;
            //        }

            //        string clicks = Regex.Replace(Convert.ToString(row["clicks"]), @"[A-Za-z\s]", string.Empty);
            //        newrow[0] = row["account"];
            //        newrow[1] = extype;
            //        newrow[2] = (Convert.ToDecimal(row["cost"]) / 1000000);
            //        newrow[3] = clicks.Replace("--", "0").Replace(",", "").Trim();
            //        newrow[4] = row["impressions"];
            //        tbl.Rows.Add(newrow);

            //    }

            //    DataSet TotalReport = new DataSet();
            //    TotalReport.Tables.Add(tbl);
            //    StringBuilder commentary = new StringBuilder();
            //    foreach (DataRow dr in TotalReport.Tables[0].Rows)
            //    {
            //        switch (Convert.ToString(dr["extensiontype"]))
            //        {
            //            case "call extensions":
            //                if (Convert.ToInt32(dr["impressions"]) > 1)
            //                { commentary.Append("Calls are important so its awesome to see you are encouraging mobile users to call you straight from your ads - these are all tracked through Google so make sure you are optimising based on call conversions.<br/><br/>"); }
            //                else
            //                { commentary.Append("If you value calls then make sure to include the click to call button alongside your ads - count calls as conversions, optimise your ads to get you more calls, and provide your customers with the easiest way to contact and buy from you!<br/><br/>"); }
            //                break;
            //            case "location extensions":
            //                if (Convert.ToInt32(dr["impressions"]) > 1)
            //                { commentary.Append("Awesome, you are providing relevant information to local customers through a location extension in your ads - make sure to keep your phone number, opening hours and reviews up to date to drive local awareness and capture your local market.<br/><br/>"); }
            //                else
            //                { commentary.Append("Location, Location Location! If you have a physical store or office it is a good idea to link it to your adwords campaigns to show relevant information alongside your ad.<br/><br/>"); }
            //                break;
            //            case "sitelinks extensions":
            //                if (Convert.ToInt32(dr["impressions"]) > 1)
            //                { commentary.Append("Great news, your account using sitelinks - we recommend deep-linking these to the most important pages on your website.<br/><br/>"); }
            //                else
            //                { commentary.Append("Sitelinks are way to easily direct potential customers to the most appropriate pages on the website - We recommend having sitelinks implemented for each of your campaigns - tailored to the useful information that potential customers looking for your products and services might be looking for.<br/><br/>"); }
            //                break;
            //            case "callouts extensions":
            //                if (Convert.ToInt32(dr["impressions"]) > 1)
            //                { commentary.Append("Way to go! Including callouts is a simple, and effective way to claim more adspace and give customers a better experience - make sure to keep testing and optimising your text.<br/><br/>"); }
            //                else
            //                { commentary.Append("Callouts are a relatively new feature which allows you to add an extra line of ad text to your ads - providing your customers with your USPs, main benefits and other calls to action.<br/><br/>"); }
            //                break;
            //            //case "review extensions": commentary.Append("<br/> Review Extension: impr-" + dr["imps"]); break;
            //            //case "structured snippets extensions": commentary.Append("<br/> structured snippets Extension: impr-" + dr["imps"]); break;
            //            //case "app extensions": commentary.Append("<br/> App Extension: impr-" + dr["imps"]); break;
            //        }
            //    }

            //    payload = payload + ",\"commentary\":\""+commentary.ToString()+"\"";
            //}
            //catch(Exception ex){

            //}
            //#endregion



            //payload = "payload = {" + payload + "}";

            //HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://hooks.zapier.com/hooks/catch/872947/uf22ru/");
            //request.Method = "POST";
            //request.ServicePoint.Expect100Continue = false;
            //request.ContentType = "application/x-www-form-urlencoded";

            //ASCIIEncoding encoding = new ASCIIEncoding();
            //byte[] byte1 = encoding.GetBytes(payload);
            //request.ContentLength = byte1.Length;
            //Stream reqStream = request.GetRequestStream();
            //reqStream.Write(byte1, 0, byte1.Length);
            //reqStream.Close();

            //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //Stream dataStream = response.GetResponseStream();
            //StreamReader reader = new StreamReader(dataStream);
            //string txtResponse = reader.ReadToEnd();


        }
    }
}