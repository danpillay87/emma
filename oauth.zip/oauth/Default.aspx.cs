﻿// Copyright 2012, Google Inc. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using Google.Api.Ads.AdWords.Lib;
using Google.Api.Ads.AdWords.Util.Reports;
using Google.Api.Ads.AdWords.v201609;
using Google.Api.Ads.Common.Lib;
using Google.Api.Ads.Common.Util.Reports;

using System;
using System.Data;
using System.IO;
using System.Web.UI.WebControls;
using System.Net;
using Newtonsoft.Json;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Configuration;

namespace meet_emma_oauth
{
    public partial class Default : System.Web.UI.Page
    {
        /// <summary>
        /// The user for creating services and making AdWords API calls.
        /// </summary>
        AdWordsUser user;
        AdWordsUser usermanager;
        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing
        /// the event data.</param>
        void Page_Load(object sender, EventArgs e)
        {
            user = new AdWordsUser();

            try
            
            {

                if (Session["OAuthProvider"] != null)
                {
                    user.Config.OAuth2Mode = OAuth2Flow.APPLICATION;
                    user.OAuthProvider = (OAuth2ProviderForApplications)Session["OAuthProvider"];

                    //OAuth2ProviderForApplications oAuth =
                    //    (user.OAuthProvider as OAuth2ProviderForApplications);
                    //oAuth.RefreshToken = xxx;
                    //oAuth.AccessToken = xxx;
                    //oAuth.UpdatedOn = xxx;
                    //oAuth.ExpiresIn = xxx;

                    Customer c = new Customer();

                    Selector selector = new Selector()
                    {
                        fields = new string[] { Convert.ToString(c.customerId), c.companyName }
                    };

                    CustomerService service =
                    (CustomerService)user.GetService(AdWordsService.v201609.CustomerService);

                    Customer[] cst = service.getCustomers();

                    usermanager = new AdWordsUser();


                    // Create a request using a URL that can receive a post. 
                    WebRequest request = WebRequest.Create("https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=" + user.OAuthProvider.AccessToken);
                    // Set the Method property of the request to POST.
                    request.Method = "GET";


                    Stream dataStream = null;


                    // Get the response.
                    WebResponse response = request.GetResponse();
                    // Display the status.
                    //Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                    // Get the stream containing content returned by the server.
                    dataStream = response.GetResponseStream();
                    // Open the stream using a StreamReader for easy access.
                    StreamReader reader = new StreamReader(dataStream);
                    // Read the content.
                    string responseFromServer = reader.ReadToEnd();
                    // Display the content.
                    //Console.WriteLine(responseFromServer);
                    // Clean up the streams.
                    reader.Close();
                    dataStream.Close();
                    response.Close();



                    Userme objects = JsonConvert.DeserializeObject<Userme>(responseFromServer); // parse as array  
                    //foreach (JObject root in objects)
                    //{
                    //    foreach (KeyValuePair<String, JToken> app in root)
                    //    {
                    //        var appName = app.Key;
                    //        var description = (String)app.Value["Description"];
                    //        var value = (String)app.Value["Value"];

                    //        Console.WriteLine(appName);
                    //        Console.WriteLine(description);
                    //        Console.WriteLine(value);
                    //        Console.WriteLine("\n");
                    //    }
                    //}

                    //objects.email

                    usermanager.Config.OAuth2Mode = OAuth2Flow.APPLICATION;
                    OAuth2ProviderForApplications oAuth1 =
                        (usermanager.OAuthProvider as OAuth2ProviderForApplications);
                    //oAuth1.RefreshToken = "1/mRiQiUvxrXk6fEOdS2Azkp5uCgxmreAkBc4xhwvxi9w";
                    //oAuth1.ClientId = "178950952337-m58d8ph74557rn25mcformu08li7n3tf.apps.googleusercontent.com";
                    //oAuth1.ClientSecret = "CBd1r5ukOBSj9pPUHnhQQ5KY";
                    oAuth1.RefreshToken = "1/1E3ogeBSZNHkaNO5bgQmd8e9cMNY9OQbX0gXfgQoeg0";
                    oAuth1.ClientId = "551007376892-4sm2antf096nu4cmjrrmf31gdn8o3tni.apps.googleusercontent.com";
                    oAuth1.ClientSecret = "Gp7tjOWpKCTeR08b_YeYvBbl";





                    ((AdWordsAppConfig)usermanager.Config).ClientCustomerId = "5277083201";
                    LinkOperation linkOp = new LinkOperation();
                    ManagedCustomerLink link = new ManagedCustomerLink();
                    //link.clientCustomerId = cst.customerId;
                    link.linkStatus = LinkStatus.PENDING;
                    link.managerCustomerId = 5277083201;//8719816531;
                    linkOp.operand = link;
                    linkOp.@operator = Operator.ADD;
                    linkOp.operatorSpecified = true;

                    ManagedCustomerService mcservice =
                   (ManagedCustomerService)usermanager.GetService(AdWordsService.v201603.ManagedCustomerService);

                    mcservice.mutateLink(new LinkOperation[] { linkOp });

                    //user.OAuthProvider.RefreshAccessToken();
                    //((AdWordsAppConfig)user.Config).OAuth2AccessToken = "1/mRiQiUvxrXk6fEOdS2Azkp5uCgxmreAkBc4xhwvxi9w";
                    //ConfigureUserForOAuth();
                    //((AdWordsAppConfig)user.Config).OAuth2RefreshToken = user.OAuthProvider.AccessToken;
                    //((AdWordsAppConfig)user.Config).ClientCustomerId = cst.customerId.ToString();
                    LinkOperation linkOp1 = new LinkOperation();
                    ManagedCustomerLink link1 = new ManagedCustomerLink();
                    //link1.clientCustomerId = cst.customerId;
                    link1.linkStatus = LinkStatus.ACTIVE;
                    link1.managerCustomerId = 2933783941;
                    linkOp1.operand = link1;
                    linkOp1.@operator = Operator.SET;

                    ManagedCustomerService mcservice1 =
                   (ManagedCustomerService)user.GetService(AdWordsService.v201603.ManagedCustomerService);

                    mcservice1.mutateLink(new LinkOperation[] { linkOp1 });
                    // ManagedCustomerService.mutateLink(new LinkOperation[] { linkOp });

                    Database db = DatabaseFactory.CreateDatabase();
                    DbCommand dbc = db.GetStoredProcCommand("USP_AddNewClient");
                    db.AddInParameter(dbc, "email", DbType.String, objects.email);
                    //db.AddInParameter(dbc, "customerid", DbType.String, cst.customerId);
                    //db.AddInParameter(dbc, "contactperson", DbType.String, cst.descriptiveName);
                    //db.AddInParameter(dbc, "companyName", DbType.String, cst.companyName);
                    DataSet report = db.ExecuteDataSet(dbc);

                    //Session["email"] = objects.email;
                    //Session["company"] = cst.companyName;
                    //Session["contactperson"] = cst.descriptiveName;
                    Session.Abandon();
                   // Response.Redirect("https://campaignhub.broadplace.com/oauth/ThankYou.aspx?cid=" + cst.customerId);
                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                Session.Abandon();

                if (ex.InnerException.Message.Contains("ACCOUNT_NOT_SET_UP"))
                {
                    Response.Redirect("https://campaignhub.broadplace.com/oauth/Error.aspx?er=1");
                }
                else if (ex.InnerException.Message.Contains("ALREADY_MANAGED_BY_THIS_MANAGER"))
                {
                    Response.Redirect("https://campaignhub.broadplace.com/oauth/Error.aspx?er=2");
                }
                else
                {
                    Response.Write(ex.Message);
                }
                //Response.Redirect("https://campaignhub.broadplace.com/oauth/Default.aspx");
            }

            /////working code
            // LinkOperation linkOp = new LinkOperation();
            // ManagedCustomerLink link = new ManagedCustomerLink();
            // link.clientCustomerId = 3730369590;
            // link.linkStatus = LinkStatus.PENDING;
            // link.managerCustomerId = 8719816531;
            // linkOp.operand = link;
            // linkOp.@operator = Operator.ADD;
            // linkOp.operatorSpecified = true;

            // ManagedCustomerService mcservice =
            //(ManagedCustomerService)user.GetService(AdWordsService.v201603.ManagedCustomerService);

            // mcservice.mutateLink(new LinkOperation[] { linkOp });
        }

        /// <summary>
        /// Handles the Click event of the btnAuthorize control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing
        /// the event data.</param>
        protected void OnAuthorizeButtonClick(object sender, EventArgs e)
        {
            // This code example shows how to run an AdWords API web application
            // while incorporating the OAuth2 web application flow into your
            // application. If your application uses a single AdWords manager account
            // login to make calls to all your accounts, you shouldn't use this code
            // example. Instead, you should run OAuthTokenGenerator.exe to generate a
            // refresh token and use that configuration in your website's Web.config.
            AdWordsAppConfig config = user.Config as AdWordsAppConfig;
            if (user.Config.OAuth2Mode == OAuth2Flow.APPLICATION &&
                  string.IsNullOrEmpty(config.OAuth2RefreshToken))
            {
                Response.Redirect("OAuthLogin.aspx");
            }
        }

        /// <summary>
        /// Handles the Click event of the btnDownloadReport control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="System.EventArgs"/> instance containing
        /// the event data.</param>
        protected void OnDownloadReportButtonClick(object sender, EventArgs eventArgs)
        {
            ConfigureUserForOAuth();
            ReportDefinition definition = new ReportDefinition()
            {
                reportName = "Last 7 days CRITERIA_PERFORMANCE_REPORT",
                reportType = ReportDefinitionReportType.CRITERIA_PERFORMANCE_REPORT,
                downloadFormat = DownloadFormat.GZIPPED_CSV,
                dateRangeType = ReportDefinitionDateRangeType.LAST_7_DAYS,

                selector = new Selector()
                {
                    fields = new string[] {"CampaignId", "AdGroupId", "Id", "CriteriaType", "Criteria",
              "FinalUrls", "Clicks", "Impressions", "Cost"},
                    predicates = new Predicate[] {
            Predicate.In("Status", new string[] {"ACTIVE", "PAUSED"})
          }
                }
            };

            // Optional: Include zero impression rows.
            AdWordsAppConfig config = (AdWordsAppConfig)user.Config;
            config.IncludeZeroImpressions = true;

            string filePath = Path.GetTempFileName();

            try
            {
                ReportUtilities utilities = new ReportUtilities(user, "v201601", definition);
                using (ReportResponse response = utilities.GetResponse())
                {
                    response.Save(filePath);
                }
            }
            catch (Exception e)
            {
                throw new System.ApplicationException("Failed to download report.", e);
            }
            Response.AddHeader("content-disposition", "attachment;filename=report.gzip");
            Response.WriteFile(filePath);
            Response.End();
        }

        /// <summary>
        /// Handles the Click event of the btnGetCampaigns control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="eventArgs">The <see cref="System.EventArgs"/> instance containing
        /// the event data.</param>
        protected void OnGetCampaignsButtonClick(object sender, EventArgs eventArgs)
        {
            ConfigureUserForOAuth();

            // Now proceed to make your API calls as usual.
            // Create a selector.
            Selector selector = new Selector()
            {
                fields = new string[] { Campaign.Fields.Id, Campaign.Fields.Name, Campaign.Fields.Status },
                ordering = new OrderBy[] { OrderBy.Asc(Campaign.Fields.Name) }
            };

            (user.Config as AdWordsAppConfig).ClientCustomerId = "";// txtCustomerId.Text; /////swagat

            try
            {
                CampaignService service =
                    (CampaignService)user.GetService(AdWordsService.v201601.CampaignService);

                CampaignPage page = service.get(selector);

                // Display campaigns.
                if (page != null && page.entries != null && page.entries.Length > 0)
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Columns.AddRange(new DataColumn[] {
              new DataColumn("Serial No.", typeof(int)),
              new DataColumn("Campaign Id", typeof(long)),
              new DataColumn("Campaign Name", typeof(string)),
              new DataColumn("Status", typeof(string))
          });
                    for (int i = 0; i < page.entries.Length; i++)
                    {
                        Campaign campaign = page.entries[i];
                        DataRow dataRow = dataTable.NewRow();
                        dataRow.ItemArray = new object[] {i + 1, campaign.id, campaign.name,
                campaign.status.ToString()
            };
                        dataTable.Rows.Add(dataRow);
                    }
                    ///swagat
                    /////CampaignGrid.DataSource = dataTable;
                    /////CampaignGrid.DataBind();
                }
                else
                {
                    Response.Write("No campaigns were found.");
                }
            }
            catch (Exception e)
            {
                Response.Write(string.Format("Failed to get campaigns. Exception says \"{0}\"",
                    e.Message));
            }
        }

        /// <summary>
        /// Configures the AdWords user for OAuth.
        /// </summary>
        private void ConfigureUserForOAuth()
        {
            AdWordsAppConfig config = (user.Config as AdWordsAppConfig);
            if (config.OAuth2Mode == OAuth2Flow.APPLICATION &&
                  string.IsNullOrEmpty(config.OAuth2RefreshToken))
            {
                user.OAuthProvider = (OAuth2ProviderForApplications)Session["OAuthProvider"];
            }
        }

        /// <summary>
        /// Handles the Click event of the btnLogout control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing
        /// the event data.</param>
        protected void OnLogoutButtonClick(object sender, EventArgs e)
        {
            Session.Clear();
        }

        /// <summary>
        /// Handles the RowDataBound event of the CampaignGrid control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The
        /// <see cref="System.Web.UI.WebControls.GridViewRowEventArgs"/> instance
        /// containing the event data.</param>
        protected void CampaignGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.DataItemIndex >= 0)
            {
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Left;
                e.Row.Cells[3].HorizontalAlign = HorizontalAlign.Center;
            }
        }
    }
    public class Userme
    {
        public string issued_to { get; set; }
        public string audience { get; set; }
        public string user_id { get; set; }
        public string scope { get; set; }
        public string expires_in { get; set; }
        public string email { get; set; }
        public string verified_email { get; set; }
        public string access_type { get; set; }
    }


}