﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace meet_emma_oauth
{
    public partial class Error : System.Web.UI.Page
    {
        string error = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            error = Convert.ToString(Request.QueryString["er"]);

            if (error == "1")
            {
                act_nodata.Visible = true;
                act_alredaymanaged.Visible = false;
            }
            else if (error == "2")
            {
                act_nodata.Visible = false;
                act_alredaymanaged.Visible = true;
            }
        }
    }
}